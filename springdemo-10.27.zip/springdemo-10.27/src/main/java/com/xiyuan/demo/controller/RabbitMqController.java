package com.xiyuan.demo.controller;


import com.xiyuan.demo.annotation.ControllerMethodLog;
import com.xiyuan.demo.entity.BusinessException;
import com.xiyuan.demo.entity.enums.CouponTypeEnum;
import com.xiyuan.demo.entity.pojo.UserInfoPojo;
import com.xiyuan.demo.entity.ResponseResult;
import com.xiyuan.demo.entity.constants.ConstantsUtil;
import com.xiyuan.demo.utils.JacksonUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageBuilder;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.AbstractJavaTypeMapper;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.*;

/**
 * 这是用户模块的Controller
 */
@RestController
@RequestMapping("/attendance/rabbitmq")
@Api(value = "用户管理")
@Slf4j
public class RabbitMqController {

    @Autowired
    RabbitTemplate rabbitTemplate;

    @Autowired
    private Environment env;


    @PostMapping("/messageString")
    @ApiOperation(value = "字符串型消息生产者")
    @ControllerMethodLog
    public ResponseResult messageString() {
        rabbitTemplate.setMessageConverter(new Jackson2JsonMessageConverter());
        rabbitTemplate.setExchange(env.getProperty("string.exchange.name"));
        rabbitTemplate.setRoutingKey(env.getProperty("string.routing.key.name"));
        try {
            Message message = MessageBuilder.withBody("发送信息".getBytes("UTF-8")).build();
            //设置请求编码格式
            message.getMessageProperties().setHeader(AbstractJavaTypeMapper.DEFAULT_CONTENT_CLASSID_FIELD_NAME, MessageProperties.CONTENT_TYPE_JSON);
            rabbitTemplate.convertAndSend(message);
        } catch (Exception e) {
            log.error("字符串型消息生产者发送消息失败" + e.getMessage(), e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR,"字符串型消息生产者发送消息失败:" + e.getMessage());

        }
        return ResponseResult.success(ConstantsUtil.OPERATE_SUCCESS);
    }

    @PostMapping("/messageObject")
    @ApiOperation(value = "object型消息生产者")
    @ControllerMethodLog
    public ResponseResult messageObject() {
        rabbitTemplate.setMessageConverter(new Jackson2JsonMessageConverter());
        rabbitTemplate.setExchange(env.getProperty("object.exchange.topic.name"));
        rabbitTemplate.setRoutingKey(env.getProperty("object.routing.key.topic.name"));

        UserInfoPojo userInfoPojo = new UserInfoPojo();
        userInfoPojo.setUserName("luo");
        userInfoPojo.setPassword("123");
        try {
            Message message = MessageBuilder.withBody(JacksonUtils.toJson(userInfoPojo).getBytes("UTF-8")).build();
            //设置请求编码格式
            message.getMessageProperties().setHeader(AbstractJavaTypeMapper.DEFAULT_CONTENT_CLASSID_FIELD_NAME, MessageProperties.CONTENT_TYPE_JSON);
            rabbitTemplate.convertAndSend(message);
        } catch (Exception e) {
            log.error("object型消息生产者发送消息失败" + e.getMessage(), e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR,"object型消息生产者发送消息失败:" + e.getMessage());
        }
        return ResponseResult.success(ConstantsUtil.OPERATE_SUCCESS);
    }
}
