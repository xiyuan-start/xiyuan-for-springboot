package com.xiyuan.demo.entity.responsestatus;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.xiyuan.demo.entity.ResponseResult;
import com.xiyuan.demo.utils.JwtTokenUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationSuccessHandler;
import org.springframework.stereotype.Component;
import com.alibaba.fastjson.JSON;

/**
 * 登录成功
 */
@Component("myAuthenctiationSuccessHandler")
@Slf4j
public class MyAuthenctiationSuccessHandler extends SimpleUrlAuthenticationSuccessHandler {

    @Autowired
    RedisTemplate redisTemplate;

    @Autowired
    JwtTokenUtil jwtTokenUtil;

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
                                        Authentication authentication) throws IOException, ServletException {
        log.info("登录成功！");
        String username = authentication.getName();
        String token =jwtTokenUtil.generateToken(username);
        response.getWriter().write(JSON.toJSONString(ResponseResult.success(token,"Login Success")));
    }
}

