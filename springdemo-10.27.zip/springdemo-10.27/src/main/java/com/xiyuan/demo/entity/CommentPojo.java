package com.xiyuan.demo.entity;

import com.alibaba.excel.metadata.BaseRowModel;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.util.Date;

/**
 * Pojo的抽象类
 */

@Setter
@Getter
@ToString
public abstract class CommentPojo extends BaseRowModel implements Serializable {

    private static final long serialVersionUID = 1L;


    private String updater;//编辑人


    private Date updateTime;//编辑时间


    private String creater; //创建人


    private Date createTime;//创建时间

}
