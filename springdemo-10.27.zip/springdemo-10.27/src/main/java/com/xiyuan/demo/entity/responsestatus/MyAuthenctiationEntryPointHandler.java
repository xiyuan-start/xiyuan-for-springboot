package com.xiyuan.demo.entity.responsestatus;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.xiyuan.demo.entity.ResponseResult;
import com.xiyuan.demo.entity.enums.CouponTypeEnum;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
/**
 * 未登录
 *
 */
@Component
@Slf4j
public class MyAuthenctiationEntryPointHandler implements AuthenticationEntryPoint{

    @Override
    public void commence(HttpServletRequest request, HttpServletResponse response,
                         AuthenticationException authException) throws IOException, ServletException {
        log.info("未登录！");
        response.getWriter().write(JSON.toJSONString(ResponseResult.error(CouponTypeEnum.NEED_LOGIN)));
    }
}

