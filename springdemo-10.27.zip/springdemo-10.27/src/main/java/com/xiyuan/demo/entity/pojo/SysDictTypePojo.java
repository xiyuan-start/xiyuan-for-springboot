package com.xiyuan.demo.entity.pojo;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.xiyuan.demo.entity.CommentPojo;
import lombok.*;

/**
 * 字典项Pojo
 */
@EqualsAndHashCode(callSuper = true)
@JsonIgnoreProperties(ignoreUnknown = true)
@Setter
@Getter
@ToString
public class SysDictTypePojo extends CommentPojo {

    private static final long serialVersionUID = 8588266045675068248L;

    private String code;//主键

    private String name;//展示值

    private String value;//真实值（唯一）


}