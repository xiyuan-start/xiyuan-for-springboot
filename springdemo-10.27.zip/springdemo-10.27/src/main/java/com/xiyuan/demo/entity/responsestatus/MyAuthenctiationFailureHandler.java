package com.xiyuan.demo.entity.responsestatus;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.xiyuan.demo.entity.ResponseResult;
import com.xiyuan.demo.entity.enums.CouponTypeEnum;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;

/**
 * 登录失败
 *
 */
@Component("myAuthenctiationFailureHandler")
@Slf4j
public class MyAuthenctiationFailureHandler extends SimpleUrlAuthenticationFailureHandler {


    @Override
    public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response,
                                        AuthenticationException exception) throws IOException, ServletException {
        log.info("登录失败！");
        response.getWriter().write(JSON.toJSONString(ResponseResult.error(CouponTypeEnum.LOGIN_FAILURE)));
    }
}



