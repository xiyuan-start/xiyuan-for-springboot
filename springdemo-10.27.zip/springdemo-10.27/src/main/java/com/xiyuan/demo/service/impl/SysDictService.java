package com.xiyuan.demo.service.impl;

import com.xiyuan.demo.dao.SysDictPojoMapper;
import com.xiyuan.demo.dao.SysDictTypePojoMapper;
import com.xiyuan.demo.service.ISysDictService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Transactional
@Service
@Slf4j
public class SysDictService implements ISysDictService {


    @Autowired
    SysDictPojoMapper sysDictPojoMapper;

    @Autowired
    SysDictTypePojoMapper sysDictTypePojoMapper;

    @Autowired
    RedisTemplate redisTemplate;

    /**
     * 转化码值
     *
     * @param distname
     * @param value
     * @return
     * @throws Exception
     */
    @Override
    @SuppressWarnings({"unchecked"})
    public String transformStr(String distname, int value) {
        Object tmp = redisTemplate.opsForValue().get(distname + "_" + value);
        return tmp != null ? tmp.toString() : String.valueOf(value);
    }
}
