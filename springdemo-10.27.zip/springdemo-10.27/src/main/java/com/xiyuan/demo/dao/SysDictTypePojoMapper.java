package com.xiyuan.demo.dao;


import com.xiyuan.demo.entity.pojo.SysDictTypePojo;
import com.xiyuan.demo.entity.pojo.TempSysDictPojo;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * 字典项的dao
 */
@Component
public interface SysDictTypePojoMapper  {

    List<TempSysDictPojo> initializationSysDict();

    int deleteByPrimaryKey(String code);

    int insert(SysDictTypePojo record);

    int insertSelective(SysDictTypePojo record);

    SysDictTypePojo selectByPrimaryKey(String code);

    int updateByPrimaryKeySelective(SysDictTypePojo record);

    int updateByPrimaryKey(SysDictTypePojo record);

}