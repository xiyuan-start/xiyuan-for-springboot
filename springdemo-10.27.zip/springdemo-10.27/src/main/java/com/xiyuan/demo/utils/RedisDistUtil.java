package com.xiyuan.demo.utils;

import com.xiyuan.demo.service.ISysDictService;
import org.springframework.context.ApplicationContext;


/**
 * 用于实现码值转化的工具类
 */
public class RedisDistUtil {
    private static ApplicationContext context;
    /**
     * 转化码值
     * @param distname
     * @param value
     * @return
     * @throws Exception
     */
    public static String transformStr(String distname, int value)  {
        ApplicationContext context = SpringUtil.getApplicationContext();
        ISysDictService iSysDictService =context.getBean(ISysDictService.class);
        return iSysDictService.transformStr(distname,value);
    }
}
