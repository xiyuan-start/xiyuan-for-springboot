package com.xiyuan.demo.entity.responsestatus;

import com.alibaba.fastjson.JSON;
import com.xiyuan.demo.entity.ResponseResult;
import com.xiyuan.demo.entity.enums.CouponTypeEnum;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.web.session.InvalidSessionStrategy;
import org.springframework.stereotype.Component;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * session到期,被登录
 */
@Component
@Slf4j
public class MyAuthenctiationSessionInformationExpiredStrategy implements InvalidSessionStrategy {


    @Override
    public void onInvalidSessionDetected(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        log.info("session到期,被登录！");
        response.getWriter().write(JSON.toJSONString(ResponseResult.error(CouponTypeEnum.SESSION_EXPIRES)));
    }

}
