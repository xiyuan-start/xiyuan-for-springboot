package com.xiyuan.demo.task;

import com.dangdang.ddframe.job.api.ShardingContext;
import com.dangdang.ddframe.job.api.simple.SimpleJob;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;

/**
 * 分布式定时任务
 */
@Slf4j
@Service
public class SimpleProducerJob implements SimpleJob {
    SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    @Override
    public void execute(ShardingContext shardingContext) {
        log.info("当前时间为"+df.format(System.currentTimeMillis()));
    }
}
