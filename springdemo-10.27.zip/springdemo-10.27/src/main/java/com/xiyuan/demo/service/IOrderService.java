package com.xiyuan.demo.service;

import com.xiyuan.demo.entity.pojo.OrderPojo;
import com.xiyuan.demo.entity.ResponseResult;

public interface IOrderService {
    /**
     * 秒杀中创建订单
     * @param orderPojo
     */
    ResponseResult seckillNewOrder(OrderPojo orderPojo);

    public ResponseResult seckillNewOrder2(OrderPojo orderPojo) throws Exception;
}
