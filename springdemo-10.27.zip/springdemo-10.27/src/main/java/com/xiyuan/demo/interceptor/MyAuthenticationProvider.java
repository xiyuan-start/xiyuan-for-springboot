package com.xiyuan.demo.interceptor;

import com.xiyuan.demo.service.comment.AuthUserDetailsService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.Collection;

/**
 * 自定义校验-密码、图片验证码
 */
@Component
@Slf4j
public class MyAuthenticationProvider implements AuthenticationProvider {


    @Autowired
    private AuthUserDetailsService authUserDetailsService;
    @Autowired
    HttpServletRequest httpServletRequest;
    @Autowired
    PasswordEncoder passwordEncoder;

    /**
     * 登录验证码SessionKey
     */
    public static final String LOGIN_VALIDATE_CODE = "login_validate_code";

    /**
     * 自定义验证方式
     */
    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {

        String token = null;
        String password = null;
        UserDetails user = null;
        if (httpServletRequest.getSession().getAttribute("token") != null) {
            token = httpServletRequest.getSession().getAttribute("token").toString();
        }
        if (StringUtils.isBlank(token)) {//使用密码进行登录  否则就是使用用户令牌进行登录
            String requestCode = httpServletRequest.getSession().getAttribute("vercode").toString();
            HttpSession session = httpServletRequest.getSession();
            String saveCode = httpServletRequest.getSession().getAttribute(LOGIN_VALIDATE_CODE).toString();
            //获取到session验证码后随时清除
            if (!StringUtils.isEmpty(saveCode)) {
                session.removeAttribute(LOGIN_VALIDATE_CODE);//captcha
                session.removeAttribute("vercode");
            }
            log.info("requestCode:" + requestCode + ",saveCode:" + saveCode);
            if (StringUtils.isEmpty(saveCode) || StringUtils.isEmpty(requestCode) || !requestCode.equals(saveCode)) {
                log.info("图片验证码错误！");
                throw new DisabledException("图形验证码错误！");
            }
            log.info("验证码验证成功");
            String username = authentication.getName();
            password = (String) authentication.getCredentials();
            user = authUserDetailsService.loadUserByUsername(username);
            //加密过程在这里体现
            log.info("结果CustomUserDetailsService后，已经查询出来的数据库存储密码:" + user.getPassword());
            if (!passwordEncoder.matches(password, user.getPassword())) {
                log.info("登录用户密码错误！");
                throw new DisabledException("登录用户密码错误！");
            }
        } else {//使用用户token进行登录
            String username = authentication.getName();
            password = (String) authentication.getCredentials();
            user = authUserDetailsService.loadUserByUsername(username);
        }
        Collection<? extends GrantedAuthority> authorities = user.getAuthorities();
        return new UsernamePasswordAuthenticationToken(user, password, authorities);
    }

    @Override
    public boolean supports(Class<?> arg0) {
        return true;
    }
}

