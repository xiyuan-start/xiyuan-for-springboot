package com.xiyuan.demo.mqlistener;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.xiyuan.demo.entity.pojo.UserInfoPojo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;


/**
 * 这里是消息队列的消费者
 */

@Component
@Slf4j
public class CommonMqListener {



    @Autowired
    RedisTemplate redisTemplate;

    private static ObjectMapper objectMapper = new ObjectMapper();



    /**
     * 监听消费消息
     *
     * @param message
     */
    @RabbitListener(queues = "${string.queue.name}", containerFactory = "singleListenerContainer")
    public void consumeStringQueue(@Payload byte[] message) {
        try {
            log.info("监听消费 监听到消息： {} ", new String(message, "UTF-8"));
        } catch (Exception e) {
            log.error("监听消费订单消息消息异常{},{}",e.getStackTrace(), e);
        }
    }

    /**
     * 监听消费消息
     *
     * @param message
     */
    @RabbitListener(queues = "${object.queue.name}", containerFactory = "multiListenerContainer")
    public void consumeObjectQueue(@Payload byte[] message) {
        try {
            UserInfoPojo userInfoPojo = objectMapper.readValue(message, UserInfoPojo.class);
            log.info("监听消费 监听到消息： {} ", userInfoPojo.toString());
        } catch (Exception e) {
            log.error("监听消费订单消息消息异常{},{}",e.getStackTrace(), e);
        }
    }
}
