package com.xiyuan.demo.controller;


import com.alibaba.fastjson.JSONObject;
import com.xiyuan.demo.annotation.AccessLimit;
import com.xiyuan.demo.annotation.ControllerMethodLog;
import com.xiyuan.demo.entity.BusinessException;
import com.xiyuan.demo.entity.enums.CouponTypeEnum;
import com.xiyuan.demo.entity.pojo.CommodityPojo;
import com.xiyuan.demo.entity.pojo.OrderPojo;
import com.xiyuan.demo.entity.ResponseResult;
import com.xiyuan.demo.service.impl.CommodityService;
import com.xiyuan.demo.utils.CommonUtil;
import com.xiyuan.demo.entity.constants.ConstantsUtil;
import com.xiyuan.demo.utils.JacksonUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageBuilder;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.AbstractJavaTypeMapper;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

/**
 * 这是用户模块的Controller
 */
@RestController
@RequestMapping("/attendance/commodity")
@Api(value = "商品模块")
@Slf4j
public class CommodityController {


    @Autowired
    CommodityService commodityService;

    @Autowired
    RabbitTemplate rabbitTemplate;

    @Autowired
    RedisTemplate redisTemplate;

    @Autowired
    private Environment env;

    /**
     * 新建商品秒杀
     */
    @PostMapping("/createSeckill")
    @ApiOperation(value = "新建商品秒杀")
    @ControllerMethodLog
    public ResponseResult createSeckill(HttpServletRequest request) {
        CommodityPojo commodityPojo = new CommodityPojo();
        commodityPojo.setCommodityAllNum(1000);
        commodityPojo.setCommodityName("测试商品一");
        commodityService.createSeckill(commodityPojo);
        return ResponseResult.success(ConstantsUtil.OPERATE_SUCCESS);
    }

    /**
     * 进行商品秒杀
     */
    @PostMapping("/seckill")
    @ApiOperation(value = "进行商品秒杀")
    @AccessLimit(limit = 4, sec = 10)  //加上自定义注解即可
    @ControllerMethodLog
    public ResponseResult seckill(HttpServletRequest request) {
        log.info("start UserController.seckill");
        String productId = "43486796d2871dfbec0f62951750ea4c";
        String user = "admin";
        OrderPojo orderPojo = new OrderPojo();
        orderPojo.setUserId(user);
        orderPojo.setProductId(productId);
        orderPojo.setOrderPrice(100L);
        orderPojo.setTempId(CommonUtil.getUUID());
        rabbitTemplate.setMessageConverter(new Jackson2JsonMessageConverter());
        rabbitTemplate.setExchange(env.getProperty("order.exchange.name"));
        rabbitTemplate.setRoutingKey(env.getProperty("order.routing.key.name"));
        try {
            Message message = MessageBuilder.withBody(JacksonUtils.toJson(orderPojo).getBytes("UTF-8")).build();
            //设置请求编码格式
            message.getMessageProperties().setHeader(AbstractJavaTypeMapper.DEFAULT_CONTENT_CLASSID_FIELD_NAME, MessageProperties.CONTENT_TYPE_JSON);
            rabbitTemplate.convertAndSend(message);
            return ResponseResult.success(orderPojo.getTempId(), ConstantsUtil.OPERATE_SUCCESS);
        } catch (Exception e) {
            log.error("订单消息生产者发送消息失败:", e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR,"订单消息生产者发送消息失败:" + e.getMessage());
        }
    }


    /**
     * 获取进行商品秒杀的结果
     */
    @PostMapping("/getSeckillResultMent")
    @ApiOperation(value = "获取进行商品秒杀的结果")
    @ControllerMethodLog
    public ResponseResult getSeckillResultMent(HttpServletRequest request, @RequestBody JSONObject jsonObject) {
        ResponseResult responseResult = null;
        String id = jsonObject.get("id").toString();
        Object o = redisTemplate.opsForValue().get("seckill_rep_" + id);
        if (o != null) {
            String tmp = o.toString();
            try {
                responseResult = JacksonUtils.toEntity(tmp, ResponseResult.class);
            } catch (Exception e) {
                log.error("获取进行商品秒杀的结果异常:" , e);
                throw new BusinessException(CouponTypeEnum.OPERATE_ERROR,"获取进行商品秒杀的结果异:" + e.getMessage());
            }
        } else {
            responseResult = ResponseResult.error(ConstantsUtil.QUERY_ERROR);
        }
        return responseResult;
    }


}
