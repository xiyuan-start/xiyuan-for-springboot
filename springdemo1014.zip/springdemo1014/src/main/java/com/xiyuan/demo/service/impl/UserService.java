package com.xiyuan.demo.service.impl;

import com.xiyuan.demo.dao.UserInfoPojoMapper;
import com.xiyuan.demo.entity.BusinessException;
import com.xiyuan.demo.entity.ResponseResult;
import com.xiyuan.demo.entity.constants.ConstantsUtil;
import com.xiyuan.demo.entity.enums.CouponTypeEnum;
import com.xiyuan.demo.entity.pojo.UserInfoPojo;
import com.xiyuan.demo.entity.param.UserInfoForSearchRes;
import com.xiyuan.demo.service.IUserService;
import com.xiyuan.demo.utils.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
@Slf4j
public class UserService  implements IUserService {

    @Autowired
    UserInfoPojoMapper userInfoPojoMapper;

    @Value(value = "${tempPath}")
    String tempPath;

    @Value(value = "${newLine}")
    String newLine;

    @Value(value = "${batchInsertCount:10}")
    Integer batchInsertCount;

    @Autowired
    SqlSessionFactory sqlSessionFactory;
    

    /**
     * 用户登录
     *
     * @param
     * @param tempPassword
     * @return
     */
    @Override
    public UserInfoPojo login(String userName, String tempPassword)  {
        try {
            return userInfoPojoMapper.login(userName, tempPassword);
        }catch (Exception e){
            log.error("用户登录失败：{}",userName, e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR,"用户登录失败:" + e.getMessage());
        }
    }

    /**
     * spring security 根据用户名获取用户
     */
    @Override
    public UserInfoPojo loginbyUsername(String userName) {
        try {
            return userInfoPojoMapper.loginbyUsername(userName);
        }catch (Exception e){
            log.error("根据用户名获取用户失败：{}",userName, e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR,"根据用户名获取用户失败:" + e.getMessage());
        }

    }


    /**
     * 用户新增
     *
     * @param userInfoPojo
     */
    @Override
    @Transactional(propagation = Propagation.SUPPORTS, isolation = Isolation.READ_COMMITTED)
    public void addUser(UserInfoPojo userInfoPojo)  {
        try {
            userInfoPojo.setId(OrderNoUtils.createUserNo(userInfoPojo.getUserName(),4));
            userInfoPojoMapper.insert(userInfoPojo);
        }catch (Exception e){
            log.error("用户:" + userInfoPojo.toString() + "新增失败" + "_" + e.getMessage(), e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR,"用户新增失败:" + e.getMessage());
        }

    }

    /**
     * 根据用户id获取用户
     *
     * @param id
     * @return
     * @
     */
    @Override
    public UserInfoPojo getUserById(String id)  {
        try {
            return userInfoPojoMapper.selectByPrimaryKey(id);
        }catch (Exception e){
            log.error("根据用户id:" + id + "查询用户失败" + "_" + e.getMessage(), e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "用户查询失败:" + e.getMessage());
        }
    }

    /**
     * 用户修改
     *
     * @param userInfoPojo
     * @
     */
    @Override
    public void updateUser(UserInfoPojo userInfoPojo)  {
        try {
            userInfoPojoMapper.updateByPrimaryKey(userInfoPojo);
        }catch (Exception e){
            log.error("用户:" + userInfoPojo.toString() + "修改失败" + "_" + e.getMessage(), e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "用户修改失败:" + e.getMessage());
        }
    }

    /**
     * 根据id删除用户
     *
     * @param id
     * @
     */
    @Override
    public void deleteUserbyId(String id)  {
        try{
            userInfoPojoMapper.deleteByPrimaryKey(id);
        }catch (Exception e){
            log.error("删除用户:" + id + "失败" + "_" + e.getMessage(), e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "用户删除失败:" + e.getMessage());
        }
    }

    /**
     * 分页查询用户模块
     *
     * @param userInfoForSearchRes
     * @return
     * @
     */
    @Override
    public Page getUserInfoByPage(UserInfoForSearchRes userInfoForSearchRes)  {
        try {
            Page page = new Page();
            //第一步获取总数据个数
            int count = userInfoPojoMapper.getUserInfoByPageCount(userInfoForSearchRes);
            page.setPageNo(userInfoForSearchRes.getPageNum());
            page.setPageSize(userInfoForSearchRes.getPageSize());
            int i = count / Integer.valueOf(userInfoForSearchRes.getPageSize());
            page.setTotalPages(i + 1);
            page.setTotalSize(count);
            //第二步：获取List
            List<UserInfoPojo> list = userInfoPojoMapper.getUserInfoByPage(userInfoForSearchRes);
            page.setValue(list);
            return page;
        }catch (Exception e){
            log.error("用户模块分页查询：:" + userInfoForSearchRes.toString() + "失败" + "_" + e.getMessage(), e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "用户列表查询失败:" + e.getMessage());
        }
    }


    /**
     * 导入Excel
     *
     * @param file
     * @param username
     * @return
     */
    @Override
    public ResponseResult importExcel(MultipartFile file, String username)throws Exception  {
        String tempfilePath = null;
        File tempfile = null;
        FileWriter fw = null;
        try {
            //第一步：创建临时文件
            String fileType = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf(".") + 1);
            tempfilePath = tempPath + CommonUtil.getUUID() + "." + fileType;
            tempfile = new File(tempfilePath);
            file.transferTo(tempfile);
            List<Object> objects = ExcelUtil.readMoreThan1000Row(tempfilePath);
            //第二步：进行Excel文件校验
            ResponseResult responseResult = checkExcel(objects, username);
            if (responseResult.getSuccess()) {//List读取成功
                List<UserInfoPojo> list = (List<UserInfoPojo>) responseResult.getValue();
                insertBatch(list);
                return ResponseResult.success(ConstantsUtil.OPERATE_SUCCESS);
            } else {//读取失败
                String errortempFile = tempPath + "/" + username + "/user/" + CommonUtil.getUUID() + ".txt";
                fw = new FileWriter(errortempFile);
                fw.write(responseResult.getErrorMsg());
                responseResult.setValue(errortempFile);
                return responseResult;
            }
        } catch (IOException e) {
            log.error("用户模块导入失败" + e.getMessage(), e);
            return ResponseResult.error(ConstantsUtil.OPERATE_ERROR);
        }catch (Exception e){
            log.error("用户管理-导入Excel异常" + e.getMessage(), e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "用户管理-导入Excel失败:" + e.getMessage());
        } finally {
            if (fw != null)
                fw.close();
            FileUtils.deleteQuietly(tempfile);
        }
    }

    /**
     * 根据ids集合获取用户
     *
     * @param listId
     * @return
     */
    @Override
    public List<UserInfoPojo> getUserInfosbyids(List<String> listId)  {
        try {
            return userInfoPojoMapper.selectByPrimaryKeys(listId);
        }catch (Exception e){
            log.error("根据ids集合获取用户失败" + e.getMessage(), e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "根据ids集合获取用户失败:" + e.getMessage());
        }
    }

    /**
     * 获取用户信息-不分页
     *
     * @param userInfoForSearchRes
     * @return
     */
    @Override
    public List<UserInfoPojo> getUserInfos(UserInfoForSearchRes userInfoForSearchRes)  {
        try {
            return userInfoPojoMapper.getUserInfoByPageNoPage(userInfoForSearchRes);
        }catch (Exception e){
            log.error("获取用户信息-不分页失败" + e.getMessage(), e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "获取用户信息-不分页失败:" + e.getMessage());
        }
    }

    /**
     * Excel文件导入
     *
     * @param list
     * @return
     */
    @Override
    public String exportExcel(List<UserInfoPojo> list)  {
        try {
            String tempfile = tempPath + CommonUtil.getUUID() + ".xlsx";
            ExcelUtil.writeWithTemplate(tempfile, list);
            return tempfile;
        }catch (Exception e){
            log.error("Excel文件导入失败" + e.getMessage(), e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "Excel文件导入失败:" + e.getMessage());
        }
    }

    /******************************私有方法**********************************/

    /**
     * 批量插入数据
     * @param list
     */
    private void insertBatch(List<UserInfoPojo> list) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        int index = list.size() / batchInsertCount;
        int count = list.size();
        long startTime = System.currentTimeMillis();   //获取开始时间
        try {
            for (int i = 0; i <= index; i++) {
                if (count > 0) {
                    try { //每一千条提交一次避免数据堆积
                        //stream流表达式，skip表示跳过前i*10000条记录，limit表示读取当前流的前1000条记录
                        userInfoPojoMapper.BatchInsert(list.stream().skip(i * batchInsertCount).limit(batchInsertCount).collect(Collectors.toList()));
                        sqlSession.commit();
                        long endTime = System.currentTimeMillis(); //获取结束时间
                        count = count - 1000;
                        log.info("用户模块批量插入-总条数：" + list.size() + ";还剩：" + (count > 0 ? count : 0) + "条，已用时：" + (endTime - startTime) + "ms");
                    } catch (Exception e) {
                        log.error("批量插入数据：" + batchInsertCount + "条一次，第" + (i + 1) + "出现异常，进行事务回滚" + e.getMessage(), e);
                        sqlSession.rollback();
                        throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "批量插入数据：" + batchInsertCount + "条一次，第" + (i + 1) + "出现异常，进行事务回滚" + e.getMessage());
                    }
                }
            }
        }catch ( BusinessException biz ){
            log.error("批量插入数据失败："+biz.getMessage() ,biz);
            throw biz;
        }finally {
            sqlSession.close();
        }
    }

    /**
     * 批量插入数据前进行数据检查
     * @param objects
     * @param username
     * @return
     */
    private ResponseResult checkExcel(List<Object> objects, String username)  {
        List<UserInfoPojo> userInfoPojos = new ArrayList<>();
        StringBuilder bf = new StringBuilder();
        if (objects != null && objects.size() > 1) {
            int i = 2;
            for (int j = 1; j < objects.size(); j++) {
                List<String> list = (List<String>) objects.get(j);
                if (list.size() < 6) {
                    bf.append("第" + i + "行中的存在大量必填项未填写，请检查" + newLine);
                    continue;
                }
                UserInfoPojo userInfoPojo = new UserInfoPojo();
                userInfoPojo.setUpdater(username);
                userInfoPojo.setCreater(username);
                userInfoPojo.setUpdateTime(new Date());
                userInfoPojo.setCreateTime(new Date());
                if (StringUtils.isBlank(list.get(0))) {
                    bf.append("第" + i + "行中的用户名为必填项不得为空" + newLine);
                } else {
                    userInfoPojo.setUserName(list.get(0));
                    userInfoPojo.setId(OrderNoUtils.createUserNo(userInfoPojo.getUserName(),4));
                }
                if (StringUtils.isBlank(list.get(1))) {
                    bf.append("第" + i + "行中的密码为必填项不得为空" + newLine);
                } else {
                    userInfoPojo.setPassword(list.get(1));
                }
                if (StringUtils.isBlank(list.get(2))) {
                    bf.append("第" + i + "行中的姓名为必填项不得为空" + newLine);
                } else {
                    userInfoPojo.setName(list.get(2));
                }
                if (StringUtils.isBlank(list.get(3))) {
                    userInfoPojo.setUserType(Short.valueOf("0"));
                } else {
                    if (MyStringUtils.iszerandone(list.get(3))) {
                        userInfoPojo.setUserType(Short.valueOf(list.get(3)));
                    } else {
                        bf.append("第" + i + "行中的用户类型为只能填写0、1或不填" + newLine);
                    }
                }
                if (StringUtils.isBlank(list.get(4))) {
                    bf.append("第" + i + "行中的性别为必填项不得为空" + newLine);
                } else {
                    if (list.get(4).equals("男")) {
                        userInfoPojo.setSex(0);
                    } else if (list.get(4).equals("女")) {
                        userInfoPojo.setSex(1);
                    } else {
                        bf.append("第" + i + "行中的性别只能填男或女" + newLine);
                    }
                }
                if (list.size() == 10 && StringUtils.isNotBlank(list.get(5)))
                    userInfoPojo.setRemark(list.get(5));

                userInfoPojos.add(userInfoPojo);
                i++;
            }
        }
        if (bf.length() > 0) {//导入失败
            log.info("批量导入检验失败："+bf.toString());
            throw  new BusinessException(CouponTypeEnum.OPERATE_ERROR,"批量导入检验失败："+bf.toString());
        } else {//导入成功
            return ResponseResult.success(userInfoPojos, ConstantsUtil.OPERATE_SUCCESS);
        }
    }

}
