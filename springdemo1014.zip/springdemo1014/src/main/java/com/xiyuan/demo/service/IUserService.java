package com.xiyuan.demo.service;


import com.xiyuan.demo.entity.ResponseResult;
import com.xiyuan.demo.entity.pojo.UserInfoPojo;
import com.xiyuan.demo.entity.param.UserInfoForSearchRes;
import com.xiyuan.demo.utils.Page;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;


/**
 * 用户模块服务类接口
 */
public interface IUserService {

    /**
     * 用户登录
     * @param userName
     * @param tempPassword
     * @return
     * @throws Exception
     */
     UserInfoPojo login(String userName, String tempPassword) throws Exception;

    /**
     * 根据用户名获取用户
     * @param userName
     * @return
     * @throws Exception
     */
    UserInfoPojo loginbyUsername(String userName) ;

    /**
     * 新增用户
     * @param userInfoPojo
     */
    void addUser(UserInfoPojo userInfoPojo) ;

    /**
     * 修改用户
     * @param userInfoPojo
     */
    void updateUser(UserInfoPojo userInfoPojo) ;

    /**
     * 根据id删除用户
     * @param id
     */
    void deleteUserbyId(String id) ;

    /**
     * 分页模糊查询
     * @param userInfoForSearchRes
     * @return
     */
    Page getUserInfoByPage(UserInfoForSearchRes userInfoForSearchRes) ;

    /**
     * 根据用户id获取用户
     * @param id
     * @return
     * @throws Exception
     */
    UserInfoPojo getUserById(String id);

    /**
     * 导入Excel
     * @param file
     * @param username
     * @return
     */
    ResponseResult importExcel(MultipartFile file, String username)throws Exception;

    /**
     * 根据id获取用户
     * @param listId
     * @return
     */
    List<UserInfoPojo> getUserInfosbyids(List<String> listId);

    /**
     * 获取用户信息（不分页）
     * @param userInfoForSearchRes
     * @return
     */
    List<UserInfoPojo> getUserInfos(UserInfoForSearchRes userInfoForSearchRes);

    /**
     * 导出Excel文件
     * @param list
     * @return
     */
    String exportExcel(List<UserInfoPojo> list);
}
