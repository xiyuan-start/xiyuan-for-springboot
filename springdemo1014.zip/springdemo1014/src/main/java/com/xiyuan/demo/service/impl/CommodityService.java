package com.xiyuan.demo.service.impl;
import com.xiyuan.demo.dao.CommodityPojoMapper;
import com.xiyuan.demo.entity.pojo.CommodityPojo;
import com.xiyuan.demo.service.ICommodityService;
import com.xiyuan.demo.utils.RedisLock;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


/**
 * 这是商品的service
 */
@Service
@Transactional
@Slf4j
public class CommodityService implements ICommodityService {

    @Autowired
    CommodityPojoMapper commodityPojoMapper;

    @Autowired
    RedisLock redisLock;

    @Autowired
    RedisTemplate redisTemplate;


    /**
     * 新建秒杀
     * @param commodityPojo
     */
    @Override
    @SuppressWarnings({ "unchecked"})
    public void createSeckill(CommodityPojo commodityPojo) {
        commodityPojoMapper.insert(commodityPojo);
        redisTemplate.opsForValue().set("seckill_"+commodityPojo.getId(), commodityPojo.getCommodityAllNum().toString());
    }

}
