package com.xiyuan.demo.service.comment;

import com.xiyuan.demo.entity.pojo.UserInfoPojo;
import com.xiyuan.demo.service.impl.UserService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Component
@Transactional
@Slf4j
public class AuthUserDetailsService implements UserDetailsService {

    @Autowired
    private UserService userService;

    
    //通过登录账号加载业务用户信息,参数为用户账号
    @Override
    public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {

        UserInfoPojo userInfoPojo = null;

        if (StringUtils.isBlank(userName)) {
            log.info("用户名不能为空！");
            throw new UsernameNotFoundException("用户名不能为空！");
        }
        try {
            userInfoPojo = userService.loginbyUsername(userName);
        } catch (Exception e) {
            log.error("用户登录时系统异常！" + e.getMessage(), e);
            throw new UsernameNotFoundException("系统异常！");
        }

        if (userInfoPojo == null) {
            log.info("登录用户" + userName + "不存在！");
            throw new UsernameNotFoundException("登录用户不存在！");
        }

        //创建security的权限实体，用于存放用户权限的
        List<SimpleGrantedAuthority> authorities = new ArrayList<>();

        //可以放入多个权限
        //这里必须以ROLE_ 开头
        if (userInfoPojo.getUserType() == 0) {
            authorities.add(new SimpleGrantedAuthority("ROLE_" + "USER"));
        } else {
            authorities.add(new SimpleGrantedAuthority("ROLE_" + "ADMIN"));
        }

        //将业务系统的用户信息以及权限信息封装到security的用户实体中
        //若入库密码已进行加密，此处则不需要解密
        return new User(userInfoPojo.getUserName(), userInfoPojo.getPassword(), authorities);
    }
}
