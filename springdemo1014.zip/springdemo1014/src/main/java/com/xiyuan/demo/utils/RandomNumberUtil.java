package com.xiyuan.demo.utils;

import java.util.Random;

/**
 * 用于生成随机数
 */
public class RandomNumberUtil {
    private RandomNumberUtil() {
    }
    public static String createRandomNumber(int length) {
        StringBuilder strBuffer = new StringBuilder();
        Random rd = new Random();
        for (int i = 0; i < length; i++) {
            strBuffer.append(rd.nextInt(10));
        }
        return strBuffer.toString();
    }
}
