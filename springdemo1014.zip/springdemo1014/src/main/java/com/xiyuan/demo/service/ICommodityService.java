package com.xiyuan.demo.service;

import com.xiyuan.demo.entity.pojo.CommodityPojo;


public interface ICommodityService {

    /**
     * 新建秒杀
     * @param commodityPojo
     */
    void createSeckill(CommodityPojo commodityPojo);

}
