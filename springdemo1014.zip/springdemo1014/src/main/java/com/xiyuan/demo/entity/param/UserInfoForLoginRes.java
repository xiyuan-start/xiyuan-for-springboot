package com.xiyuan.demo.entity.param;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;

/**
 * 这是用户查询的封装类
 */
@Setter
@Getter
@ToString
@ApiModel("用户登录请求类")
public class UserInfoForLoginRes implements Serializable {
    private static final long serialVersionUID = -26311050319074021L;


    @NotNull(message = "用户名为必填项，不得为空")
    @Size(min = 2,max = 20,message = "用户名长度要在2—8个字符")
    @ApiModelProperty(required = true, notes = "用户名", example = "xiyuan666")
    private String userName;

    @NotNull(message = "密码为必填项，不得为空")
    @Size(min = 10,max = 20,message = "用户名长度要在10—20个字符")
    @ApiModelProperty(required = true, notes = "密码", example = "123456")
    private String password;

    @NotNull(message = "验证码为必填项，不得为空")
    @ApiModelProperty(required = true, notes = "验证码", example = "123456")
    private String vercode;

}
