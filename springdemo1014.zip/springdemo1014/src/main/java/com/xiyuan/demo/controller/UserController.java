package com.xiyuan.demo.controller;


import com.google.code.kaptcha.impl.DefaultKaptcha;
import com.xiyuan.demo.annotation.ControllerMethodLog;
import com.xiyuan.demo.entity.BusinessException;
import com.xiyuan.demo.entity.ResponseResult;
import com.xiyuan.demo.entity.constants.ConstantsUtil;
import com.xiyuan.demo.entity.enums.CouponTypeEnum;
import com.xiyuan.demo.entity.param.UserInfoForLoginRes;
import com.xiyuan.demo.entity.param.UserInfoPojoRes;
import com.xiyuan.demo.entity.pojo.UserInfoPojo;
import com.xiyuan.demo.entity.param.UserInfoForSearchRes;
import com.xiyuan.demo.service.impl.UserService;
import com.xiyuan.demo.utils.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import java.io.*;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 这是用户模块的Controller
 */
@RestController
@RequestMapping("/demo/userinfo")
@Api(value = "用户管理")
@Slf4j
public class UserController {

    @Autowired
    UserService userService;

    @Value(value = "${server.port}")
    String port;

    @Value(value = "${server.address}")
    String serverPath;

    @Resource
    private DefaultKaptcha captchaProducer;

    @Autowired
    DozerBeanMapper dozerBeanMapper;


    /**
     * 登录验证码SessionKey
     */
    public static final String LOGIN_VALIDATE_CODE = "login_validate_code";


    @PostMapping("/loginUser")
    @ApiOperation(value = "用户登录")
    @ControllerMethodLog
    public ResponseResult login(@Valid @RequestBody UserInfoForLoginRes userInfoForLoginRes) {
        return ResponseResult.success(userInfoForLoginRes, ConstantsUtil.OPERATE_SUCCESS);
    }

    @PostMapping(value = {"/loginValidateCode"})
    @ApiOperation(value = "获取验证码图片")
    @ControllerMethodLog
    public void loginValidateCode(HttpServletRequest request, HttpServletResponse response) throws Exception {
        CommonUtil.validateCode(request, response, captchaProducer, LOGIN_VALIDATE_CODE);
    }

    @PostMapping("/addUser")
    @ApiOperation(value = "用户新增")
    @ControllerMethodLog
    public ResponseResult addUser(@Valid @RequestBody UserInfoPojoRes userInfoPojoRes) {
        userInfoPojoRes.setUserType((short) 0); //默认添加的都是普通用户
        //用户密码加密
        userInfoPojoRes.setPassword(BCryptPasswordEncoderUtils.encodePassword(userInfoPojoRes.getPassword()));
        //实体类转化
        UserInfoPojo userInfoPojo = dozerBeanMapper.map(userInfoPojoRes, UserInfoPojo.class);
        userService.addUser(userInfoPojo);
        return ResponseResult.success(ConstantsUtil.OPERATE_SUCCESS);
    }


    @GetMapping("/getUserById")
    @ApiOperation(value = "根据用户id获取用户")
    @ControllerMethodLog
    public ResponseResult getUserById(@RequestParam(name = "id", required = true) String id) {
        UserInfoPojo userInfoPojo = userService.getUserById(id);
        return ResponseResult.success(userInfoPojo, ConstantsUtil.QUERY_SUCCESS);
    }

    @PostMapping("/updateUser")
    @ApiOperation(value = "用户修改")
    @ControllerMethodLog
    public ResponseResult updateUser(@Valid @RequestBody UserInfoPojoRes userInfoPojoRes) {
        //用户密码加密
        userInfoPojoRes.setPassword(BCryptPasswordEncoderUtils.encodePassword(userInfoPojoRes.getPassword()));
        //实体类转化
        UserInfoPojo userInfoPojo = dozerBeanMapper.map(userInfoPojoRes, UserInfoPojo.class);
        userService.updateUser(userInfoPojo);
        return ResponseResult.success(ConstantsUtil.OPERATE_SUCCESS);
    }

    @GetMapping("/deleteUserbyId")
    @ApiOperation(value = "用户删除")
    @ControllerMethodLog
    public ResponseResult deleteUserbyId(@RequestParam(name = "id", required = true) String id) {
        userService.deleteUserbyId(id);
        return ResponseResult.success(ConstantsUtil.OPERATE_SUCCESS);
    }

    @PostMapping("/queryUserListPage")
    @ApiOperation(value = "用户分页模糊查询")
    @ControllerMethodLog
    public ResponseResult queryUserListPage(@RequestBody UserInfoForSearchRes userInfoForSearchRes) {
        long startTime = System.currentTimeMillis();   //获取开始时间
        Page page = userService.getUserInfoByPage(userInfoForSearchRes);
        long endTime = System.currentTimeMillis(); //获取结束时间
        log.info("用户模块分页查询-总条数：" + page.getTotalSize() + "用时：" + (endTime - startTime) + "ms");
        return ResponseResult.success(page, ConstantsUtil.QUERY_SUCCESS);
    }

    @GetMapping("/downErrorTxt")
    @ApiOperation(value = "用户管理-下载错误日志txt")
    @ControllerMethodLog
    public ResponseResult downErrorTxt(HttpServletResponse response, @RequestParam(required = false) String input) throws Exception {
        BufferedInputStream bis = null;
        BufferedOutputStream bos = null;
        FileInputStream fileInputStream = null;
        try {
            if (StringUtils.isNotBlank(input)) {
                File file = new File(input);
                if (!file.exists()) {
                    log.error("错误日志文件不存在" );
                    throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "错误日志文件不存在");
                }
                fileInputStream = new FileInputStream(input);
                // 设置response参数，可以打开下载页面
                response.reset();
                response.setContentType("application/vnd.ms-excel;charset=utf-8");
                response.setHeader("Content-Disposition", "attachment;filename=" + new String(("错误日志文件.txt").getBytes(), "iso-8859-1"));//下载文件的名称
                ServletOutputStream out = response.getOutputStream();
                bis = new BufferedInputStream(fileInputStream);
                bos = new BufferedOutputStream(out);
                byte[] buff = new byte[2048];
                int bytesRead;
                while (-1 != (bytesRead = bis.read(buff, 0, buff.length))) {
                    bos.write(buff, 0, bytesRead);
                }
            }
        } catch (Exception e) {
            log.error("下载错误提示信息失败" + e.getMessage(), e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "下载错误日志txt失败:" + e.getMessage());
        } finally {
            if (fileInputStream != null)
                fileInputStream.close();
            if (bis != null)
                bis.close();
            if (bos != null)
                bos.close();
        }
        return ResponseResult.success(ConstantsUtil.QUERY_ERROR);
    }

    @GetMapping("/exportExcelTemplate")
    @ApiOperation(value = "用户管理-下载导入模板")
    @ControllerMethodLog
    public void exportExcelTemplate(HttpServletResponse response){
        String str = "/files/用户导入模板.xlsx";
        try {
            ClassPathResource classPathResource = new ClassPathResource(str);
            InputStream is = classPathResource.getInputStream();
            // 根据excel创建对象
            Workbook workbook = WorkbookFactory.create(is);
            String fileName = "用户导入模板.xlsx";
            ExcelUtil.downLoadExcel(fileName, response, workbook);
        } catch (Exception e) {
            log.error("用户模块下载导入模板" + e.getMessage(), e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "用户模块下载导入模板失败:" + e.getMessage());
        }
    }

    @PostMapping("/importExcel")
    @ApiOperation(value = "用户管理-导入Excel")
    @ControllerMethodLog
    public ResponseResult importExcel(HttpServletRequest request, MultipartFile file)  {
        try {
            //从HttpSession中获取当前用户的username
            HttpSession session = request.getSession();
            UserInfoPojo temp = (UserInfoPojo) session.getAttribute("loginUser");
            String username = temp.getUserName();
            ResponseResult responseResult = userService.importExcel(file, username);
            if (responseResult.getSuccess()) {//批量导入成功
                responseResult.setErrorMsg(ConstantsUtil.OPERATE_SUCCESS);
            } else {//操作失败
                if (responseResult.getValue() != null) {
                    String tempfile = responseResult.getValue().toString();
                    responseResult.setValue("http://" + serverPath + ":" + port + "/startingpoint/userinfo/downerrorTxt?input=" + tempfile);
                }
            }
            return responseResult;
        } catch (Exception e) {
            log.error("用户管理-导入Excel异常" + e.getMessage(), e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "用户管理-导入Excel失败:" + e.getMessage());
        }
    }

    @GetMapping("/exportExcel")
    @ApiOperation(value = "查询问卷管理-导出Excel")
    @ControllerMethodLog
    public ResponseResult exportExcel(@RequestParam(required = false) String ids, @RequestBody(required = false) UserInfoForSearchRes userInfoForSearchRes, HttpServletResponse response) throws IOException {
        List<String> listId;
        File f = null;
        FileInputStream inputStream = null;
        try {
            if (StringUtils.isNotBlank(ids)) {
                listId = Arrays.asList(ids.split(","))
                        .stream().map(s -> s.trim())
                        .collect(Collectors.toList());
            } else {
                listId = null;
            }
            List<UserInfoPojo> list;
            if (listId == null || listId.size() == 0) {
                list = userService.getUserInfos(userInfoForSearchRes);
            } else {
                list = userService.getUserInfosbyids(listId);
            }

            long startTime = System.currentTimeMillis();   //获取开始时间
            String tempfile = userService.exportExcel(list);
            long endTime = System.currentTimeMillis(); //获取结束时间
            log.info("问卷模块导出Excel文件条数：" + list.size() + "用时：" + (endTime - startTime) + "ms");

            f = new File(tempfile);
            inputStream = new FileInputStream(f);
            // 根据excel创建对象
            Workbook workbook = WorkbookFactory.create(inputStream);
            String fileName = "用户模块" + DateUtils.getTodayStr() + ".xlsx";
            ExcelUtil.downLoadExcel(fileName, response, workbook);
            return ResponseResult.success(ConstantsUtil.OPERATE_SUCCESS);
        } catch (Exception e) {
            log.error("用户模板导出Excel异常" + e.getMessage(), e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "用户管理-导出Excel失败:" + e.getMessage());
        } finally {
            if (inputStream != null)
                inputStream.close();
            FileUtils.deleteQuietly(f);
        }
    }

    /**
     * 用于校验实体类是否合法
     *
     * @param userInfoPojo
     * @return
     */
    private String entityCheckPojo(UserInfoPojo userInfoPojo) {
        StringBuffer bf = new StringBuffer();
        if (StringUtils.isBlank(userInfoPojo.getUserName())) {
            bf.append("用户名是必填项不得为空！;");
        }
        if (StringUtils.isBlank(userInfoPojo.getPassword())) {
            bf.append("密码是必填项不得为空！;");
        }
        if (bf.length() > 0) {
            bf.substring(0, bf.length() - 1);
        }
        return bf.toString();
    }

}
