package com.xiyuan.demo.service;



public interface ISysDictService {

    /**
     * 根据码表name以及value值来获取码表值
     * @param distname
     * @param value
     * @return
     * @throws Exception
     */
    String  transformStr(String distname,int value) ;
}
